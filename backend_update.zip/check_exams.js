const { Pool } = require('pg');
require('dotenv').config();

const pool = new Pool({
    connectionString: process.env.DATABASE_URL || 'postgresql://postgres:camilo99@localhost:5432/telephases',
    ssl: false
});

async function checkRecentExams() {
    try {
        console.log('🔍 Verificando exámenes recientes...\n');
        
        // Consultar exámenes de hoy  
        const result = await pool.query(`
            SELECT 
                e.id,
                te.nombre as tipo_examen_nombre,
                e.titulo,
                e.valor,
                e.unidad,
                e.observaciones,
                e.datos_adicionales,
                e.fecha_creacion
            FROM examen e
            INNER JOIN tipo_examen te ON e.tipo_examen_id = te.id
            WHERE e.fecha_creacion >= CURRENT_DATE 
            ORDER BY e.fecha_creacion DESC
        `);
        
        if (result.rows.length === 0) {
            console.log('❌ No se encontraron exámenes de hoy');
            return;
        }
        
        console.log(`✅ Se encontraron ${result.rows.length} examen(es) de hoy:\n`);
        
        result.rows.forEach((exam, index) => {
            console.log(`📋 EXAMEN ${index + 1}:`);
            console.log(`   🏷️  Tipo: ${exam.tipo_examen_nombre}`);
            console.log(`   📝 Título: ${exam.titulo}`);
            console.log(`   📊 Valor: ${exam.valor} ${exam.unidad || ''}`);
            console.log(`   💬 Observaciones: ${exam.observaciones}`);
            console.log(`   🕐 Fecha: ${exam.fecha_creacion}`);
            
            if (exam.datos_adicionales) {
                console.log(`   📋 Datos adicionales: ${JSON.stringify(exam.datos_adicionales, null, 2)}`);
            }
            console.log('   ' + '-'.repeat(50) + '\n');
        });
        
        // Estadísticas por tipo
        console.log('📈 RESUMEN POR TIPO:');
        const stats = result.rows.reduce((acc, exam) => {
            acc[exam.tipo_examen_nombre] = (acc[exam.tipo_examen_nombre] || 0) + 1;
            return acc;
        }, {});
        
        Object.entries(stats).forEach(([tipo, count]) => {
            console.log(`   ${tipo}: ${count} examen(es)`);
        });
        
    } catch (error) {
        console.error('❌ Error consultando exámenes:', error.message);
    } finally {
        await pool.end();
        process.exit(0);
    }
}

checkRecentExams(); 