// Backend/index.js

require('dotenv').config();
const express    = require('express');
const cors       = require('cors');
const bcrypt     = require('bcrypt');
const jwt        = require('jsonwebtoken');
const { Pool }   = require('pg');
const https      = require('https');
const fs         = require('fs');

const app = express();
app.use(cors());
app.use(express.json());

// Configuración de base de datos usando variables de entorno
const pool = new Pool({
    host: process.env.DB_HOST || 'localhost',
    port: parseInt(process.env.DB_PORT) || 5432,
    user: process.env.DB_USERNAME || 'postgres', 
    password: process.env.DB_PASSWORD || 'camilo99',
    database: process.env.DB_NAME || 'telephases',
    ssl: process.env.NODE_ENV === 'production' ? { rejectUnauthorized: false } : false
});

const JWT_SECRET = process.env.JWT_SECRET || 'development_jwt_secret_change_in_production';

// Genera JWT con userId y email
function generateToken(user) {
  return jwt.sign(
    { userId: user.id, email: user.email, rolId: user.rol_id },
    JWT_SECRET,
    { expiresIn: '2h' }
  );
}

// Registro de usuario
app.post('/register', async (req, res) => {
  const {
    username,
    email,
    password,
    primer_nombre,
    segundo_nombre,
    primer_apellido,
    segundo_apellido,
    tipo_documento_id,
    numero_documento,
    telefono,
    direccion,
    ciudad_id,
    fecha_nacimiento,
    genero,
    rol_id
  } = req.body;

  // Validación mínima
  if (!username || !email || !password
      || !primer_nombre || !primer_apellido
      || !tipo_documento_id || !numero_documento
      || !primer_apellido || !rol_id) {
    return res.status(400).json({ error: 'Faltan campos obligatorios' });
  }

  try {
    // 1) Hash de contraseña
    const hash = await bcrypt.hash(password, 10);

    // 2) Insert SQL (id, fecha_registro, etc. usan sus defaults)
    const insertSQL = `
      INSERT INTO public.usuario
        (username, email, password_hash,
         primer_nombre, segundo_nombre,
         primer_apellido, segundo_apellido,
         tipo_documento_id, numero_documento,
         telefono, direccion, ciudad_id,
         fecha_nacimiento, genero, rol_id)
      VALUES ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14,$15)
      RETURNING id, email, rol_id
    `;
    const values = [
      username, email, hash,
      primer_nombre, segundo_nombre || null,
      primer_apellido, segundo_apellido || null,
      tipo_documento_id, numero_documento,
      telefono || null, direccion || null,
      ciudad_id || null,
      fecha_nacimiento || null,
      genero || null,
      rol_id
    ];

    const { rows } = await pool.query(insertSQL, values);
    const user = rows[0];

    // 3) Genera y devuelve JWT
    const token = generateToken(user);
    res.status(201).json({ token });

  } catch (err) {
    console.error('Error en /register:', err);
    if (err.code === '23505') {
      // Violación de unique (email, username o documento)
      return res.status(409).json({ error: 'Usuario o datos duplicados' });
    }
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});

// … rutas /login, /profile, etc. …

// Middleware para autenticación
function authenticateToken(req, res, next) {
  const authHeader = req.headers['authorization'];
  const token = authHeader && authHeader.split(' ')[1];

  if (!token) {
    return res.status(401).json({ error: 'Token de acceso requerido' });
  }

  jwt.verify(token, JWT_SECRET, (err, user) => {
    if (err) {
      return res.status(403).json({ error: 'Token inválido' });
    }
    req.user = user;
    next();
  });
}

// ENDPOINTS PARA EXÁMENES

// Obtener exámenes del usuario autenticado
app.get('/examenes', authenticateToken, async (req, res) => {
  try {
    const { page = 1, limit = 20 } = req.query;
    const offset = (page - 1) * limit;
    
    const query = `
      SELECT e.id, e.titulo, e.valor, e.unidad, 
             e.fecha_creacion, e.fecha_modificacion, e.observaciones,
             te.nombre as tipo_examen_nombre,
             te.descripcion as tipo_examen_descripcion,
             e.datos_adicionales
      FROM examen e
      INNER JOIN tipo_examen te ON e.tipo_examen_id = te.id
      WHERE e.usuario_id = $1 AND e.activo = TRUE
      ORDER BY e.fecha_creacion DESC 
      LIMIT $2 OFFSET $3
    `;
    
    const { rows } = await pool.query(query, [req.user.userId, limit, offset]);
    res.json({ examenes: rows });
  } catch (err) {
    console.error('Error obteniendo exámenes:', err);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});

// Crear nuevo examen
app.post('/examenes', authenticateToken, async (req, res) => {
  const { tipo_examen_nombre, titulo, valor, unidad, observaciones, datos_adicionales } = req.body;
  
  if (!tipo_examen_nombre || !titulo || !valor) {
    return res.status(400).json({ error: 'Campos requeridos: tipo_examen_nombre, titulo, valor' });
  }
  
  try {
    // Obtener el ID del tipo de examen
    const tipoQuery = 'SELECT id FROM tipo_examen WHERE nombre = $1';
    const { rows: tipoRows } = await pool.query(tipoQuery, [tipo_examen_nombre]);
    
    if (tipoRows.length === 0) {
      return res.status(400).json({ error: 'Tipo de examen no válido' });
    }
    
    const tipoExamenId = tipoRows[0].id;
    
    // Insertar examen
    const query = `
      INSERT INTO examen (usuario_id, tipo_examen_id, titulo, valor, unidad, observaciones, datos_adicionales, sincronizado)
      VALUES ($1, $2, $3, $4, $5, $6, $7, TRUE)
      RETURNING id, titulo, valor, unidad, fecha_creacion, fecha_modificacion, observaciones
    `;
    
    const values = [
      req.user.userId, 
      tipoExamenId, 
      titulo, 
      valor, 
      unidad || null, 
      observaciones || null,
      datos_adicionales ? JSON.stringify(datos_adicionales) : null
    ];
    
    const { rows } = await pool.query(query, values);
    
    console.log(`✅ Examen creado: ${titulo} = ${valor} ${unidad || ''} para usuario ${req.user.userId}`);
    res.status(201).json({ 
      examen: rows[0],
      message: 'Examen guardado exitosamente'
    });
  } catch (err) {
    console.error('Error creando examen:', err);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});

// Obtener últimos exámenes de cada tipo
app.get('/examenes/ultimos', authenticateToken, async (req, res) => {
  try {
    const query = `
      SELECT DISTINCT ON (te.nombre) 
        e.id, e.titulo, e.valor, e.unidad, e.fecha_creacion, e.observaciones,
        te.nombre as tipo_examen_nombre,
        te.descripcion as tipo_examen_descripcion,
        e.datos_adicionales
      FROM examen e
      INNER JOIN tipo_examen te ON e.tipo_examen_id = te.id
      WHERE e.usuario_id = $1 AND e.activo = TRUE
      ORDER BY te.nombre, e.fecha_creacion DESC
    `;
    
    const { rows } = await pool.query(query, [req.user.userId]);
    res.json({ examenes: rows });
  } catch (err) {
    console.error('Error obteniendo últimos exámenes:', err);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});

const PORT = process.env.PORT || 3001;

// Para desarrollo: usar HTTP en lugar de HTTPS
app.listen(PORT, '0.0.0.0', () => {
  console.log(`🟢 API escuchando en http://0.0.0.0:${PORT} (accesible desde la red local)`);
  console.log(`📊 Endpoints de exámenes disponibles:`);
  console.log(`   GET  /examenes - Obtener exámenes del usuario`);
  console.log(`   POST /examenes - Crear nuevo examen`);
  console.log(`   GET  /examenes/ultimos - Últimos exámenes por tipo`);
});

// Endpoint de login
app.post('/login', async (req, res) => {
  const { username, password } = req.body;

  // Validación básica
  if (!username || !password) {
    return res.status(400).json({ error: 'Se requiere usuario y contraseña' });
  }

  try {
    // Buscar usuario por username o email
    const query = `
      SELECT id, username, email, password_hash, rol_id
      FROM public.usuario
      WHERE username = $1 OR email = $1
    `;

    const { rows } = await pool.query(query, [username]);

    // Usuario no encontrado
    if (rows.length === 0) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    const user = rows[0];

    // Verificar contraseña
    const isValid = await bcrypt.compare(password, user.password_hash);

    if (!isValid) {
      return res.status(401).json({ error: 'Credenciales inválidas' });
    }

    // Generar y devolver token
    const token = generateToken(user);
    res.json({ token });

  } catch (err) {
    console.error('Error en /login:', err);
    res.status(500).json({ error: 'Error interno del servidor' });
  }
});