const { Pool } = require('pg');

const pool = new Pool({
    connectionString: 'postgresql://postgres:camilo99@localhost:5432/telephases',
    ssl: false
});

async function main() {
    try {
        console.log('🔍 VERIFICANDO EXÁMENES...\n');
        
        // Consulta simple para ver los exámenes de hoy
        const query = `
            SELECT 
                e.id,
                e.titulo,
                e.valor,
                e.unidad,
                e.fecha_creacion,
                te.nombre as tipo
            FROM examen e
            INNER JOIN tipo_examen te ON e.tipo_examen_id = te.id
            WHERE e.fecha_creacion::date = CURRENT_DATE
            ORDER BY e.fecha_creacion DESC
            LIMIT 10
        `;
        
        const result = await pool.query(query);
        
        if (result.rows.length === 0) {
            console.log('❌ No hay exámenes de hoy');
        } else {
            console.log(`✅ ENCONTRADOS ${result.rows.length} EXÁMENES DE HOY:\n`);
            
            result.rows.forEach((exam, i) => {
                console.log(`${i + 1}. ${exam.tipo}: ${exam.titulo}`);
                console.log(`   📊 Valor: ${exam.valor} ${exam.unidad || ''}`);
                console.log(`   📅 ${exam.fecha_creacion}`);
                console.log('   ' + '-'.repeat(40));
            });
        }
        
    } catch (error) {
        console.error('❌ Error:', error.message);
    } finally {
        await pool.end();
        process.exit(0);
    }
}

main(); 